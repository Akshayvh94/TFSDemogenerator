﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VstsDemoBuilder.Models
{
    public class Query
    {
        public string name { get; set; }
        public string wiql { get; set; }
    }
}