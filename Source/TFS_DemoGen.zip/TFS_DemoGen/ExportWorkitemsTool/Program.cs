﻿using TemplatesGeneratorTool.Generators;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TemplatesGeneratorTool
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string PAT = string.Empty;
            string accountName = string.Empty;
            string tfsName = string.Empty;
            string port = string.Empty;
            string collectionName = string.Empty;
            string projectName = string.Empty;

            Console.WriteLine("Welcome to TFS Data Tool");
            Console.WriteLine("Press Y for online,and press N for TFS onpremise");

            char onlinekey = Console.ReadKey().KeyChar;
            VstsRestAPI.Configuration vstsAPIConfiguration;
            Configuration sourceconfig;
            VstsRestAPI.Configuration vstsConfigForReleaseDefinitions;

            if (onlinekey == 'Y' || onlinekey == 'y')
            {
                Console.WriteLine("");
                Console.WriteLine("Please enter Account Name");
                accountName = Console.ReadLine();

                Console.WriteLine("Please enter Personel access token");
                PAT = ReadPassword();

                Console.WriteLine("Please enter project name");
                projectName = Console.ReadLine();

                sourceconfig = new Configuration() { UriString = "https://" + accountName + ".visualstudio.com/DefaultCollection/", PersonalAccessToken = PAT, Project = projectName };
                vstsAPIConfiguration = new VstsRestAPI.Configuration() { UriString = "https://" + accountName + ".visualstudio.com/DefaultCollection/", PersonalAccessToken = PAT, Project = projectName };
                vstsConfigForReleaseDefinitions = new VstsRestAPI.Configuration() { UriString = "https://" + accountName + "vsrm.visualstudio.com/DefaultCollection/", PersonalAccessToken = PAT, Project = projectName };
            }
            else
            {
                Console.WriteLine("");
                Console.WriteLine("\nPlease enter TFS server name");
                tfsName = Console.ReadLine();

                Console.WriteLine("\nPlease enter port");
                port = Console.ReadLine();

                Console.WriteLine("\nPlease enter collection name");
                collectionName = Console.ReadLine();

                Console.WriteLine("\nPlease enter project name");
                projectName = Console.ReadLine();

                Console.WriteLine("\nPlease enter personel access token");
                PAT = ReadPassword();

                string TFSUriString = string.Format("http://{0}:{1}/tfs/{2}/", tfsName, port, collectionName);

                sourceconfig = new Configuration() { UriString = TFSUriString, PersonalAccessToken = PAT, Project = projectName };
                vstsAPIConfiguration = new VstsRestAPI.Configuration() { UriString = TFSUriString, PersonalAccessToken = PAT, Project = projectName };
                vstsConfigForReleaseDefinitions = new VstsRestAPI.Configuration() { UriString = TFSUriString, PersonalAccessToken = PAT, Project = projectName };
            }

            Console.WriteLine("\nGenerating templates....");
            Console.WriteLine();


            Dictionary<string, string> queryList = new Dictionary<string, string>();
            ExportQueries objQuery = new ExportQueries(vstsAPIConfiguration);
            //queryList = objQuery.GetQueries(projectName);
            queryList = objQuery.GetQueriesByPath(projectName, string.Empty);

            ExportWidgetsAndCharts objWidgetAndCharts = new ExportWidgetsAndCharts(vstsAPIConfiguration);
            objWidgetAndCharts.GetWidgetsAndCharts(projectName, queryList);


            Teams objTeam = new Teams(vstsAPIConfiguration);
            objTeam.ExportTeams(projectName);
            Console.WriteLine("Teams JSON is saved into Template folder");
            Console.WriteLine("");

            ServiceEndpoints objService = new ServiceEndpoints(vstsAPIConfiguration);

            string serviceEndPoint = string.Empty;
            serviceEndPoint = objService.ExportServiceEndPoints(projectName);
            Console.WriteLine("ServiceEndPoint JSONs are saved into Template folder");
            Console.WriteLine("");

            SourceCode objSourceCode = new SourceCode(vstsAPIConfiguration);
            objSourceCode.ExportSourceCode(projectName);
            Console.WriteLine("ImportSourceCode JSON is saved into Template folder");
            Console.WriteLine("");

            BoardColumns objColumn = new BoardColumns(vstsAPIConfiguration);
            objColumn.ExportBoardColumns(projectName);
            Console.WriteLine("BoardColumn JSON file is saved into Template folder");
            Console.WriteLine("");

            GenerateWIFromSource wiql = new GenerateWIFromSource(sourceconfig, accountName);
            wiql.UpdateWorkItem();
            Console.WriteLine("Work item JSON files are saved into Templates folder");
            Console.WriteLine("");

            BuildDefinitions objBuild = new BuildDefinitions(vstsAPIConfiguration, accountName);
            ReleaseDefinitions objRelease = new ReleaseDefinitions(vstsConfigForReleaseDefinitions, accountName);
            objBuild.ExportBuildDefinitions(projectName);
            objRelease.ExportReleaseDefinitions(projectName, serviceEndPoint);
            Console.WriteLine("Build and Release Definitions are saved into Templates folder");
            Console.WriteLine("");

            CardFieldsAndCardStyles objCards = new CardFieldsAndCardStyles(vstsAPIConfiguration);
            objCards.GetCardFields(projectName);
            objCards.GetCardStyles(projectName);
            Console.WriteLine("CardField and CardStyle JSON files are saved into Templates folder");
            Console.WriteLine("");

            Iterations objIterations = new Iterations(vstsAPIConfiguration, accountName);
            objIterations.GetIterations();
            Console.WriteLine("iterations JSON file is saved into Templates folder");
            Console.WriteLine("");

            Console.WriteLine("Completed generating templates from " + projectName);
            var wait = Console.ReadLine();
        }

        public static string ReadPassword()
        {
            string password = "";
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                    {
                        // remove one character from the list of password characters
                        password = password.Substring(0, password.Length - 1);
                        // get the location of the cursor
                        int pos = Console.CursorLeft;
                        // move the cursor to the left by one character
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                        // replace it with space
                        Console.Write(" ");
                        // move the cursor to the left by one character again
                        Console.SetCursorPosition(pos - 1, Console.CursorTop);
                    }
                }
                info = Console.ReadKey(true);
            }
            // add a new line because user pressed enter at the end of their password
            Console.WriteLine();
            return password;
        }
    }
}
      