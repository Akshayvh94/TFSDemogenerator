﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TemplatesGeneratorTool.ViewModel;

namespace TemplatesGeneratorTool.Generators
{
    public class SourceCode
    {
        readonly VstsRestAPI.IConfiguration _sourceConfig;
        readonly string _sourceCredentials;

        public SourceCode(VstsRestAPI.IConfiguration configuration)
        {
            _sourceConfig = configuration;
            _sourceCredentials = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "", _sourceConfig.PersonalAccessToken)));
        }

        public void ExportSourceCode(string project)
        {
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(_sourceConfig.UriString);
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _sourceCredentials);

                    HttpResponseMessage response = client.GetAsync(_sourceConfig.UriString + string.Format("{0}/_apis/git/repositories?api-version=1.0", project)).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        RepositoryResponse.Repository repository = Newtonsoft.Json.JsonConvert.DeserializeObject<RepositoryResponse.Repository>(response.Content.ReadAsStringAsync().Result.ToString());
                        if (repository.count > 0)
                        {
                            int count = 1;
                            foreach (var repoId in repository.value)
                            {
                                using (var client1 = new HttpClient())
                                {
                                    client1.BaseAddress = new Uri(_sourceConfig.UriString);
                                    client1.DefaultRequestHeaders.Accept.Clear();
                                    client1.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                                    client1.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _sourceCredentials);

                                    HttpResponseMessage responseCode = client1.GetAsync(_sourceConfig.UriString + string.Format("{0}/_apis/git/repositories/{1}/importRequests?includeAbandoned=true&api-version=3.0-preview", project, repoId.id)).Result;
                                    if (response.IsSuccessStatusCode)
                                    {
                                        SourceCodeResponse.Code code = Newtonsoft.Json.JsonConvert.DeserializeObject<SourceCodeResponse.Code>(responseCode.Content.ReadAsStringAsync().Result.ToString());
                                        if (code.value != null)
                                        {
                                            //SourceCodeResponse.Value sourceCode = code.value[0];

                                            if (!Directory.Exists(@"Templates\sourceCode"))
                                            {
                                                Directory.CreateDirectory(@"Templates\sourceCode");
                                            }
                                            string fetchedSourceCodeJSON = JsonConvert.SerializeObject(code.value, Formatting.Indented);
                                            File.WriteAllText(@"Templates\sourceCode\importSourceCode" + count + ".json", fetchedSourceCodeJSON);
                                            count = count + 1;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
        }
    }
}
