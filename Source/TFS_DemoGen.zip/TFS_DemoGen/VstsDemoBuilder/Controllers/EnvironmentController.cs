﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Diagnostics;
using VstsDemoBuilder.Models;
using VstsRestAPI;
using VstsRestAPI.Build;
using VstsRestAPI.Git;
using VstsRestAPI.ProjectsAndTeams;
using VstsRestAPI.Release;
using VstsRestAPI.Service;
using VstsRestAPI.Viewmodel.ProjectAndTeams;
using VstsRestAPI.WorkItemAndTracking;
using VstsDemoBuilder.Extensions;
using VstsRestAPI.Queues;
using VstsRestAPI.Viewmodel.WorkItem;
using VstsRestAPI.Viewmodel.QuerysAndWidgets;
using VstsRestAPI.QuerysAndWidgets;
using System.Dynamic;
using Microsoft.VisualStudio.Services.WebApi;
using Microsoft.VisualStudio.Services.Common;
using Microsoft.VisualStudio.Services.ExtensionManagement.WebApi;
using System.Net;

namespace VstsDemoBuilder.Controllers
{
    public class EnvironmentController : Controller
    {
        #region Variables & Properties
        private static object objLock = new object();
        private static Dictionary<string, string> statusMessages;
        delegate string[] ProcessEnvironment(Project model, string PAT, string accountName);

        private static Dictionary<string, string> StatusMessages
        {
            get
            {
                if (statusMessages == null)
                {
                    statusMessages = new Dictionary<string, string>();
                }

                return statusMessages;
            }
            set
            {
                statusMessages = value;
            }
        }
        #endregion

        #region Manage Status Messages
        public void AddMessage(string id, string message)
        {
            lock (objLock)
            {
                if (id.EndsWith("_Errors"))
                {
                    StatusMessages[id] = (StatusMessages.ContainsKey(id) ? StatusMessages[id] : string.Empty) + message;
                }
                else
                {
                    StatusMessages[id] = message;
                }
            }
        }

        public void RemoveKey(string id)
        {
            lock (objLock)
            {
                StatusMessages.Remove(id);
            }
        }

        public ContentResult GetCurrentProgress(string id)
        {
            this.ControllerContext.HttpContext.Response.AddHeader("cache-control", "no-cache");
            var currentProgress = GetStatusMessage(id).ToString();
            return Content(currentProgress);
        }

        public string GetStatusMessage(string id)
        {
            lock (objLock)
            {
                string message = string.Empty;
                if (StatusMessages.Keys.Count(x => x == id) == 1)
                {
                    message = StatusMessages[id];
                }
                else
                {
                    return "100";
                }

                if (id.EndsWith("_Errors"))
                {
                    RemoveKey(id);
                }

                return message;
            }
        }

        public ContentResult GetTemplate(string TemplateName)
        {
            string templatesPath = Server.MapPath("~") + @"\Templates\";
            string template = string.Empty;

            if (System.IO.File.Exists(templatesPath + Path.GetFileName(TemplateName) + @"\ProjectTemplate.json"))
            {
                Project objP = new Project();
                template = objP.ReadJsonFile(templatesPath + Path.GetFileName(TemplateName) + @"\ProjectTemplate.json");
            }
            return Content(template);
        }
        #endregion

        #region Controller Actions
        public ActionResult Create(Project model)
        {
            model.Templates = new List<string>();
            TemplateSetting privateTemplates = new TemplateSetting();
            string[] dirTemplates = Directory.GetDirectories(Server.MapPath("~") + @"\Templates");

            foreach (string template in dirTemplates)
            {
                model.Templates.Add(Path.GetFileName(template));
            }
            if (System.IO.File.Exists(Server.MapPath("~") + @"\Templates\TemplateSetting.json"))
            {
                string privateTemplatesJson = model.ReadJsonFile(Server.MapPath("~") + @"\Templates\TemplateSetting.json");
                privateTemplates = Newtonsoft.Json.JsonConvert.DeserializeObject<TemplateSetting>(privateTemplatesJson);
            }
            model.SupportEmail = System.Configuration.ConfigurationManager.AppSettings["SupportEmail"];
            foreach (string template in privateTemplates.privateTemplates)
            {
                model.Templates.Remove(template);
            }
            if (!string.IsNullOrEmpty(model.SelectedTemplate))
            {
                foreach (string template in privateTemplates.privateTemplates)
                {
                    if (template.ToLower() == model.SelectedTemplate.ToLower())
                    {
                        model.Templates.Add(template);
                    }
                }
            }
            return View(model);
        }

        public bool StartEnvironmentSetupProcess(Project model)
        {

            if (model.isTFS)
            {
                if (Session["PAT"] == null)
                {
                    return false;
                }
                string PAT = Session["PAT"].ToString();
                AddMessage(model.id, string.Empty);
                AddMessage(model.id.ErrorId(), string.Empty);

                ProcessEnvironment processTask = new ProcessEnvironment(CreateProjectEnvironment);
                processTask.BeginInvoke(model, PAT, string.Empty, new AsyncCallback(EndEnvironmentSetupProcess), processTask);
                return true;

            }
            else
            {
                if (Session["PAT"] == null || Session["AccountName"] == null)
                {
                    return false;
                }
                string PAT = Session["PAT"].ToString();
                string accountName = Session["AccountName"].ToString();

                AddMessage(model.id, string.Empty);
                AddMessage(model.id.ErrorId(), string.Empty);

                ProcessEnvironment processTask = new ProcessEnvironment(CreateProjectEnvironment);
                processTask.BeginInvoke(model, PAT, accountName, new AsyncCallback(EndEnvironmentSetupProcess), processTask);
                return true;
            }
        }

        public void EndEnvironmentSetupProcess(IAsyncResult result)
        {
            ProcessEnvironment processTask = (ProcessEnvironment)result.AsyncState;
            string[] strResult = processTask.EndInvoke(result);

            RemoveKey(strResult[0]);
            if (StatusMessages.Keys.Count(x => x == strResult[0] + "_Errors") == 1)
            {
                string errorMessages = statusMessages[strResult[0] + "_Errors"];
                if (errorMessages != "")
                {
                    //also, log message to file system
                    string LogPath = Server.MapPath("~") + @"\Log";
                    string accountName = strResult[1];
                    string fileName = string.Format("{0}_{1}.txt", accountName, DateTime.Now.ToString("ddMMMyyyy_HHmmss"));

                    if (!Directory.Exists(LogPath))
                        Directory.CreateDirectory(LogPath);
                    System.IO.File.AppendAllText(Path.Combine(LogPath, fileName), errorMessages);
                }
            }
        }
        public string[] CreateProjectEnvironment(Project model, string PAT, string accountName)
        {
            //define versions to be use
            string defaultVersion = System.Configuration.ConfigurationManager.AppSettings["Version2.2"];
            string ver2_0 = System.Configuration.ConfigurationManager.AppSettings["Version2.0"];
            string Ver3_0 = System.Configuration.ConfigurationManager.AppSettings["Version3.0"];
            string processTemplateId = Default.SCRUM;
            model.Environment = new EnvironmentValues();
            model.Environment.ServiceEndpoints = new Dictionary<string, string>();
            model.Environment.RepositoryIdList = new Dictionary<string, string>();
            ProjectTemplate template = null;
            ProjectSettings settings = null;

            //configuration setup
            string _credentials = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "", PAT)));

            Configuration _defaultConfiguration = new Configuration() { };
            Configuration _releaseDefinitionConfiguration = new Configuration() { };
            Configuration _createReleaseConfiguration = new Configuration() { };
            Configuration _configuration3_0 = new Configuration() { };
            Configuration _configuration2_0 = new Configuration() { };
            Configuration _cardConfiguration = new Configuration() { };

            if (model.isTFS)
            {
                //TFS Configuration
                _defaultConfiguration = new Configuration() { UriString = string.Format("http://{0}:{1}/tfs/{2}/", model.TFSserverName, model.Port, model.Collection), VersionNumber = defaultVersion, PersonalAccessToken = PAT };
                _releaseDefinitionConfiguration = new Configuration() { UriString = string.Format("http://{0}:{1}/tfs/{2}/", model.TFSserverName, model.Port, model.Collection), VersionNumber = defaultVersion, PersonalAccessToken = PAT };
                _createReleaseConfiguration = new Configuration() { UriString = string.Format("http://{0}:{1}/tfs/{2}/", model.TFSserverName, model.Port, model.Collection), VersionNumber = Ver3_0, PersonalAccessToken = PAT };
                _configuration3_0 = new Configuration() { UriString = string.Format("http://{0}:{1}/tfs/{2}/", model.TFSserverName, model.Port, model.Collection), VersionNumber = Ver3_0, PersonalAccessToken = PAT, Project = model.ProjectName };
                _configuration2_0 = new Configuration() { UriString = string.Format("http://{0}:{1}/tfs/{2}/", model.TFSserverName, model.Port, model.Collection), VersionNumber = ver2_0, PersonalAccessToken = PAT };
                _cardConfiguration = new Configuration() { UriString = string.Format("http://{0}:{1}/tfs:", model.TFSserverName, model.Port), VersionNumber = ver2_0, PersonalAccessToken = PAT };
            }
            else
            {
                //VSTS Configuration
                _defaultConfiguration = new Configuration() { UriString = "https://" + accountName + ".visualstudio.com/DefaultCollection/", VersionNumber = defaultVersion, PersonalAccessToken = PAT };
                _releaseDefinitionConfiguration = new Configuration() { UriString = "https://" + accountName + ".vsrm.visualstudio.com/DefaultCollection/", VersionNumber = defaultVersion, PersonalAccessToken = PAT };
                _createReleaseConfiguration = new Configuration() { UriString = "https://" + accountName + ".vsrm.visualstudio.com/DefaultCollection/", VersionNumber = Ver3_0, PersonalAccessToken = PAT };
                _configuration3_0 = new Configuration() { UriString = "https://" + accountName + ".visualstudio.com/DefaultCollection/", VersionNumber = Ver3_0, PersonalAccessToken = PAT, Project = model.ProjectName };
                _configuration2_0 = new Configuration() { UriString = "https://" + accountName + ".visualstudio.com/DefaultCollection/", VersionNumber = ver2_0, PersonalAccessToken = PAT };
                _cardConfiguration = new Configuration() { UriString = "https://" + accountName + ".visualstudio.com:", VersionNumber = ver2_0, PersonalAccessToken = PAT };
            }

            string templatesFolder = Server.MapPath("~") + @"\Templates\";
            string projTemplateFile = string.Format(templatesFolder + @"{0}\ProjectTemplate.json", model.SelectedTemplate);
            string projectSettingsFile = string.Empty;

            //initialize project template and settings
            if (System.IO.File.Exists(projTemplateFile))
            {
                string templateItems = model.ReadJsonFile(projTemplateFile);
                template = JsonConvert.DeserializeObject<ProjectTemplate>(templateItems);

                projectSettingsFile = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.ProjectSettings);
                if (System.IO.File.Exists(projectSettingsFile))
                {
                    settings = JsonConvert.DeserializeObject<ProjectSettings>(model.ReadJsonFile(projectSettingsFile));

                    if (!string.IsNullOrWhiteSpace(settings.type))
                    {
                        if (settings.type.ToLower() == TemplateType.Scrum.ToString().ToLower()) processTemplateId = Default.SCRUM;
                        else if (settings.type.ToLower() == TemplateType.Agile.ToString().ToLower()) processTemplateId = Default.Agile;
                        else if (settings.type.ToLower() == TemplateType.CMMI.ToString().ToLower()) processTemplateId = Default.CMMI;
                    }
                }
            }
            else
            {
                AddMessage(model.id, "Project Template not found");
                StatusMessages[model.id] = "100";
                return new string[] { model.id, accountName };
            }

            //create team project
            AddMessage(model.id, string.Format("Creating project {0}...", model.ProjectName));
            string jsonProject = model.ReadJsonFile(templatesFolder + "CreateProject.json");
            jsonProject = jsonProject.Replace("$projectName$", model.ProjectName).Replace("$processTemplateId$", processTemplateId);

            Projects proj = new Projects(_defaultConfiguration);
            string projectId = proj.CreateTeamProject(jsonProject);

            if (projectId == "-1")
            {
                AddMessage(model.id, proj.lastFailureMessage);
                Thread.Sleep(1000);
                return new string[] { model.id, accountName };
            }

            //Check for project state 
            Stopwatch watch = new Stopwatch();
            watch.Start();
            string projectStatus = string.Empty;
            Projects objProject = new Projects(_defaultConfiguration);
            while (projectStatus.ToLower() != "wellformed")
            {
                projectStatus = objProject.GetProjectStateByName(model.ProjectName);
                if (watch.Elapsed.Minutes >= 5)
                {
                    return new string[] { model.id, accountName };
                }
            }
            watch.Stop();

            //get project id after successfull in VSTS
            model.Environment.ProjectId = objProject.GetProjectIdByName(model.ProjectName);
            model.Environment.ProjectName = model.ProjectName;

            //create teams
            CreateTeams(templatesFolder, model, template.Teams, _defaultConfiguration, model.id);

            //current user Details
            string teamName = model.ProjectName + " team";
            TeamMemberResponse.TeamMembers teamMembers = GetTeamMembers(model.ProjectName, teamName, _defaultConfiguration, model.id);
            var teamMember = teamMembers.value.FirstOrDefault();
            if (teamMember != null) model.Environment.UserUniquename = teamMember.uniqueName;

            //update board columns and rows
            AddMessage(model.id, "Updating board columns,rows,styles and enabling Epic...");
            string updateSwimLanesJSON = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.BoardRows);
            SwimLanes objSwimLanes = new SwimLanes(_configuration2_0);
            bool isUpdated = objSwimLanes.UpdateSwimLanes(updateSwimLanesJSON, model.ProjectName);

            bool success = UpdateBoardColumn(templatesFolder, model, template.BoardColumns, _configuration2_0, model.id);
            if (success)
            {
                //update Card Fields
                UpdateCardFields(templatesFolder, model, template.CardField, _cardConfiguration, model.id);

                //Update card styles
                UpdateCardStyles(templatesFolder, model, template.CardStyle, _cardConfiguration, model.id);

                //Enable Epic Backlog
                EnableEpic(templatesFolder, model, template.SetEpic, _configuration3_0, model.id);
            }

            //update sprint dates
            AddMessage(model.id, "Updating sprint dates...");
            UpdateSprintItems(model, _defaultConfiguration, settings);
            //UpdateIterations(model, _defaultConfiguration, templatesFolder, "iterations.json");
            RenameIterations(model, _defaultConfiguration, settings.renameIterations);

            //create service endpoint
            AddMessage(model.id, "Creating service endpoint...");
            List<string> lstEndPointsJsonPath = new List<string>();
            string serviceEndPointsPath = templatesFolder + model.SelectedTemplate + @"\ServiceEndpoints";
            if (System.IO.Directory.Exists(serviceEndPointsPath))
            {
                System.IO.Directory.GetFiles(serviceEndPointsPath).ToList().ForEach(i => lstEndPointsJsonPath.Add(i));
            }
            string endPointJson = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, template.CreateService);
            lstEndPointsJsonPath.Add(endPointJson);
            CreateServiceEndPoint(model, lstEndPointsJsonPath, _configuration3_0);

            //create agent queues on demand
            Queue queue = new Queue(_configuration3_0);
            model.Environment.AgentQueues = queue.GetQueues();
            if (settings.queues != null && settings.queues.Count > 0)
            {
                foreach (string aq in settings.queues)
                {
                    if (model.Environment.AgentQueues.ContainsKey(aq)) continue;
                    var id = queue.CreateQueue(aq);
                    if (id > 0) model.Environment.AgentQueues[aq] = id;
                }
            }

            //import source code from GitHub
            AddMessage(model.id, "Importing source code...");

            List<string> lstImportSourceCodeJsonPaths = new List<string>();
            string importSourceCodePath = templatesFolder + model.SelectedTemplate + @"\ImportSourceCode";
            if (System.IO.Directory.Exists(importSourceCodePath))
            {
                System.IO.Directory.GetFiles(importSourceCodePath).ToList().ForEach(i => lstImportSourceCodeJsonPaths.Add(i));
            }
            foreach (string importSourceCode in lstImportSourceCodeJsonPaths)
            {
                ImportSourceCode(templatesFolder, model, importSourceCode, _defaultConfiguration, _configuration3_0, model.id);
            }
            Repository objRepository = new Repository(_defaultConfiguration);
            string repositoryToDelete = objRepository.GetRepositoryToDelete(model.ProjectName);
            bool isDeleted = objRepository.DeleteRepository(repositoryToDelete);

            //import work items
            AddMessage(model.id, "Creating work items ...");
            string featuresFilePath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.FeaturefromTemplate);
            string productBackLogPath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.PBIfromTemplate);
            string taskPath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.TaskfromTemplate);
            string testCasePath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.TestCasefromTemplate);
            string bugPath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.BugfromTemplate);
            string epicPath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.EpicfromTemplate);
            string userStoriesPath = System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.UserStoriesFromTemplate);
            //string testSuitePath= System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.TestSuitesFromTemplate);
            //string testPlanPath= System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.TestPlanFromTemplate);
            //string feedBackRequestPath= System.IO.Path.Combine(templatesFolder + model.SelectedTemplate, template.FeedbackRequestFromTemplate);

            Dictionary<string, string> WorkItems = new Dictionary<string, string>();

            if (System.IO.File.Exists(featuresFilePath)) WorkItems.Add("Feature", model.ReadJsonFile(featuresFilePath));
            if (System.IO.File.Exists(productBackLogPath)) WorkItems.Add("Product Backlog Item", model.ReadJsonFile(productBackLogPath));
            if (System.IO.File.Exists(taskPath)) WorkItems.Add("Task", model.ReadJsonFile(taskPath));
            if (System.IO.File.Exists(testCasePath)) WorkItems.Add("Test Case", model.ReadJsonFile(testCasePath));
            if (System.IO.File.Exists(bugPath)) WorkItems.Add("Bug", model.ReadJsonFile(bugPath));
            if (System.IO.File.Exists(userStoriesPath)) WorkItems.Add("User Story", model.ReadJsonFile(userStoriesPath));
            if (System.IO.File.Exists(epicPath)) WorkItems.Add("Epic", model.ReadJsonFile(epicPath));
            //if (System.IO.File.Exists(testSuitePath)) WorkItems.Add("Test Suite", model.ReadJsonFile(testSuitePath));
            //if (System.IO.File.Exists(testPlanPath)) WorkItems.Add("Test Plan", model.ReadJsonFile(testPlanPath));
            //if (System.IO.File.Exists(feedBackRequestPath)) WorkItems.Add("FeedBack Request", model.ReadJsonFile(feedBackRequestPath));

            ImportWorkItems import = new ImportWorkItems(_defaultConfiguration, model.Environment.BoardRowFieldName);
            if (System.IO.File.Exists(projectSettingsFile))
            {
                string AttchmentFilesFolder = string.Format(templatesFolder + @"{0}\WorkItemAttachments", model.SelectedTemplate);
                bool isImported = import.ImportWorkitems(WorkItems, model.ProjectName, model.Environment.UserUniquename, model.ReadJsonFile(projectSettingsFile), AttchmentFilesFolder);

            }
            Thread.Sleep(5000);
            //create build Definition
            AddMessage(model.id, "Creating build definition...");
            string BuildDefinitionsPath = templatesFolder + model.SelectedTemplate + @"\BuildDefinitions";
            model.BuildDefinitions = new List<BuildDef>();
            if (System.IO.Directory.Exists(BuildDefinitionsPath))
            {
                System.IO.Directory.GetFiles(BuildDefinitionsPath, "*.json", SearchOption.AllDirectories).ToList().ForEach(i => model.BuildDefinitions.Add(new Models.BuildDef() { FilePath = i }));
            }
            CreateBuildDefinition(templatesFolder, model, _defaultConfiguration, model.id);

            //create release Definition
            Thread.Sleep(5000);

            AddMessage(model.id, "Creating release definition...");
            string ReleaseDefinitionsPath = templatesFolder + model.SelectedTemplate + @"\ReleaseDefinitions";
            model.ReleaseDefinitions = new List<ReleaseDef>();
            if (System.IO.Directory.Exists(ReleaseDefinitionsPath))
            {
                System.IO.Directory.GetFiles(ReleaseDefinitionsPath, "*.json", SearchOption.AllDirectories).ToList().ForEach(i => model.ReleaseDefinitions.Add(new Models.ReleaseDef() { FilePath = i }));
            }
            CreateReleaseDefinition(templatesFolder, model, _releaseDefinitionConfiguration, _configuration3_0, model.id, teamMembers);

            //Create query and widgets
            List<string> lstDashboardQueriesPath = new List<string>();
            string dashboardQueriesPath = templatesFolder + model.SelectedTemplate + @"\Dashboard\Queries";
            if (System.IO.Directory.Exists(dashboardQueriesPath))
            {
                System.IO.Directory.GetFiles(dashboardQueriesPath).ToList().ForEach(i => lstDashboardQueriesPath.Add(i));
            }
            AddMessage(model.id, "Creating queries,widgets and charts...");
            CreateQueryAndWidgets(templatesFolder, model, lstDashboardQueriesPath, _defaultConfiguration, _configuration2_0, _configuration3_0, _releaseDefinitionConfiguration);


            StatusMessages[model.id] = "100";
            return new string[] { model.id, accountName };
        }
        #endregion

        #region Project Setup Operations
        private void CreateTeams(string templatesFolder, Project model, string teamsJSON, Configuration _defaultConfiguration, string id)
        {
            try
            {
                string jsonTeams = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, teamsJSON);
                if (System.IO.File.Exists(jsonTeams))
                {
                    Team objTeam = new Team(_defaultConfiguration);
                    jsonTeams = model.ReadJsonFile(jsonTeams); //System.IO.File.ReadAllText(jsonTeams);
                    JArray jTeams = JsonConvert.DeserializeObject<JArray>(jsonTeams);
                    Newtonsoft.Json.Linq.JContainer teamsParsed = Newtonsoft.Json.JsonConvert.DeserializeObject<Newtonsoft.Json.Linq.JContainer>(jsonTeams);

                    AddMessage(id, string.Format("Creating {0} teams...", teamsParsed.Count));

                    foreach (var jTeam in jTeams)
                    {
                        GetTeamResponse.Team teamResponse = objTeam.CreateNewTeam(jTeam.ToString(), model.ProjectName);
                    }

                    if (!(string.IsNullOrEmpty(objTeam.lastFailureMessage)))
                    {
                        AddMessage(id.ErrorId(), "Error while creating teams: " + objTeam.lastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while creating teams: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        private TeamMemberResponse.TeamMembers GetTeamMembers(string projectName, string teamName, Configuration _configuration, string id)
        {
            try
            {
                TeamMemberResponse.TeamMembers viewModel = new TeamMemberResponse.TeamMembers();
                Team objTeam = new Team(_configuration);
                viewModel = objTeam.GetTeamMembers(projectName, teamName);

                if (!(string.IsNullOrEmpty(objTeam.lastFailureMessage)))
                {
                    AddMessage(id.ErrorId(), "Error while getting team members: " + objTeam.lastFailureMessage + Environment.NewLine);
                }
                return viewModel;
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while getting team members: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }

            return new TeamMemberResponse.TeamMembers();
        }

        private void CreateWorkItems(string templatesFolder, Project model, string workItemJSON, Configuration _defaultConfiguration, string id)
        {
            try
            {
                string jsonWorkItems = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, workItemJSON);
                if (System.IO.File.Exists(jsonWorkItems))
                {
                    WorkItemNew objWorkItem = new WorkItemNew(_defaultConfiguration);
                    jsonWorkItems = model.ReadJsonFile(jsonWorkItems);
                    Newtonsoft.Json.Linq.JContainer WorkItemsParsed = Newtonsoft.Json.JsonConvert.DeserializeObject<Newtonsoft.Json.Linq.JContainer>(jsonWorkItems);

                    AddMessage(id, "Creating " + WorkItemsParsed.Count + " work items...");

                    jsonWorkItems = jsonWorkItems.Replace("$version$", _defaultConfiguration.VersionNumber);
                    bool workItemResult = objWorkItem.CreateWorkItemUsingByPassRules(model.ProjectName, jsonWorkItems);

                    if (!(string.IsNullOrEmpty(objWorkItem.lastFailureMessage)))
                    {
                        AddMessage(id.ErrorId(), "Error while creating workitems: " + objWorkItem.lastFailureMessage + Environment.NewLine);
                    }
                }

            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while creating workitems: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        private bool UpdateBoardColumn(string templatesFolder, Project model, string BoardColumnsJSON, Configuration _defaultConfiguration, string id)
        {
            bool res = false;
            try
            {
                string jsonBoardColumns = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, BoardColumnsJSON);
                if (System.IO.File.Exists(jsonBoardColumns))
                {
                    BoardColumn objBoard = new BoardColumn(_defaultConfiguration);
                    jsonBoardColumns = model.ReadJsonFile(jsonBoardColumns);
                    bool BoardColumnResult = objBoard.UpdateBoard(model.ProjectName, jsonBoardColumns);

                    if (BoardColumnResult)
                    {
                        model.Environment.BoardRowFieldName = objBoard.rowFieldName;
                        res = true;
                    }
                    else if (!(string.IsNullOrEmpty(objBoard.lastFailureMessage)))
                    {
                        AddMessage(id.ErrorId(), "Error while updating board column " + objBoard.lastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while updating board column " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
            return res;
        }

        private void UpdateCardFields(string templatesFolder, Project model, string json, Configuration _configuration, string id)
        {
            try
            {
                json = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, json);
                if (System.IO.File.Exists(json))
                {
                    json = model.ReadJsonFile(json);
                    Cards objCards = new Cards(_configuration);
                    objCards.UpdateCardField(model.ProjectName, json);

                    if (!string.IsNullOrEmpty(objCards.LastFailureMessage))
                    {
                        AddMessage(id.ErrorId(), "Error while updating card fields: " + objCards.LastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while updating card fields: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }

        }

        private void UpdateCardStyles(string templatesFolder, Project model, string json, Configuration _configuration, string id)
        {
            try
            {
                json = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, json);
                if (System.IO.File.Exists(json))
                {
                    json = model.ReadJsonFile(json);
                    Cards objCards = new Cards(_configuration);
                    objCards.ApplyRules(model.ProjectName, json);

                    if (!string.IsNullOrEmpty(objCards.LastFailureMessage))
                    {
                        AddMessage(id.ErrorId(), "Error while updating card styles: " + objCards.LastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while updating card styles: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }

        }

        private void EnableEpic(string templatesFolder, Project model, string json, Configuration _config3_0, string id)
        {
            try
            {
                json = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, json);
                if (System.IO.File.Exists(json))
                {
                    json = model.ReadJsonFile(json);
                    Cards objCards = new Cards(_config3_0);
                    Projects project = new Projects(_config3_0);
                    objCards.EnablingEpic(model.ProjectName, json, model.ProjectName);

                    if (!string.IsNullOrEmpty(objCards.LastFailureMessage))
                    {
                        AddMessage(id.ErrorId(), "Error while Setting Epic Settings: " + objCards.LastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while Setting Epic Settings: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }

        }

        private void UpdateWorkItems(string templatesFolder, Project model, string workItemUpdateJSON, Configuration _defaultConfiguration, string id, string currentUser, string ProjectSettingsJSON)
        {
            try
            {
                string jsonWorkItemsUpdate = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, workItemUpdateJSON);
                string jsonProjectSettings = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, ProjectSettingsJSON);
                if (System.IO.File.Exists(jsonWorkItemsUpdate))
                {
                    WorkItemNew objWorkItem = new WorkItemNew(_defaultConfiguration);
                    jsonWorkItemsUpdate = model.ReadJsonFile(jsonWorkItemsUpdate);
                    jsonProjectSettings = model.ReadJsonFile(jsonProjectSettings);

                    bool workItemUpdateResult = objWorkItem.UpdateWorkItemUsingByPassRules(jsonWorkItemsUpdate, model.ProjectName, currentUser, jsonProjectSettings);
                    if (!(string.IsNullOrEmpty(objWorkItem.lastFailureMessage)))
                    {
                        AddMessage(id.ErrorId(), "Error while updating work items: " + objWorkItem.lastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while updating work items: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        private void UpdateIterations(Project model, Configuration _defaultConfiguration, string templatesFolder, string iterationsJSON)
        {
            try
            {
                string jsonIterations = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, iterationsJSON);
                if (System.IO.File.Exists(jsonIterations))
                {
                    iterationsJSON = model.ReadJsonFile(jsonIterations);
                    ClassificationNodes ObjClassification = new ClassificationNodes(_defaultConfiguration);

                    GetNodesResponse.Nodes nodes = ObjClassification.GetIterations(model.ProjectName);

                    GetNodesResponse.Nodes projectNode = JsonConvert.DeserializeObject<GetNodesResponse.Nodes>(iterationsJSON);

                    if (projectNode.hasChildren)
                    {
                        foreach (var child in projectNode.children)
                        {
                            CreateIterationNode(model, ObjClassification, child, nodes);
                        }
                    }

                    if (projectNode.hasChildren)
                    {
                        foreach (var child in projectNode.children)
                        {
                            path = string.Empty;
                            MoveIterationNode(model, ObjClassification, child);
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                AddMessage(model.id.ErrorId(), "Error while updating iteration: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        private void CreateIterationNode(Project model, ClassificationNodes ObjClassification, GetNodesResponse.Child child, GetNodesResponse.Nodes currentIterations)
        {
            string[] defaultSprints = new string[] { "Sprint 1", "Sprint 2", "Sprint 3", "Sprint 4", "Sprint 5", "Sprint 6", };
            if (defaultSprints.Contains(child.name))
            {
                var nd = (currentIterations.hasChildren) ? currentIterations.children.FirstOrDefault(i => i.name == child.name) : null;
                if (nd != null) child.id = nd.id;
            }
            else
            {
                var node = ObjClassification.CreateIteration(model.ProjectName, child.name);
                child.id = node.id;
            }

            if (child.hasChildren && child.children != null)
            {
                foreach (var c in child.children)
                {
                    CreateIterationNode(model, ObjClassification, c, currentIterations);
                }
            }
        }

        string path = string.Empty;
        private void MoveIterationNode(Project model, ClassificationNodes ObjClassification, GetNodesResponse.Child child)
        {
            if (child.hasChildren && child.children != null)
            {
                foreach (var c in child.children)
                {
                    path += child.name + "\\";
                    var nd = ObjClassification.MoveIteration(model.ProjectName, path, c.id);

                    if (c.hasChildren)
                    {
                        MoveIterationNode(model, ObjClassification, c);
                    }
                }
            }
        }

        private void UpdateSprintItems(Project model, Configuration _defaultConfiguration, ProjectSettings settings)
        {
            try
            {
                ClassificationNodes ObjClassification = new ClassificationNodes(_defaultConfiguration);
                bool ClassificationNodesResult = ObjClassification.UpdateIterationDates(model.ProjectName, settings.type);

                if (!(string.IsNullOrEmpty(ObjClassification.LastFailureMessage)))
                {
                    AddMessage(model.id.ErrorId(), "Error while updating sprint items: " + ObjClassification.LastFailureMessage + Environment.NewLine);
                }
            }
            catch (Exception ex)
            {
                AddMessage(model.id.ErrorId(), "Error while updating sprint items: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }
        public void RenameIterations(Project model, Configuration _defaultConfiguration, Dictionary<string, string> renameIterations)
        {
            try
            {
                if (renameIterations != null && renameIterations.Count > 0)
                {
                    ClassificationNodes ObjClassification = new ClassificationNodes(_defaultConfiguration);
                    bool IsRenamed = ObjClassification.RenameIteration(model.ProjectName, renameIterations);
                }
            }
            catch (Exception ex)
            {
                AddMessage(model.id.ErrorId(), "Error while renaming iterations: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }
        private void ImportSourceCode(string templatesFolder, Project model, string sourceCodeJSON, Configuration _defaultConfiguration, Configuration importSourceConfiguration, string id)
        {

            try
            {
                //string jsonSourceCode = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, sourceCodeJSON);
                if (System.IO.File.Exists(sourceCodeJSON))
                {
                    Repository objRepository = new Repository(_defaultConfiguration);
                    string repositoryName = Path.GetFileName(sourceCodeJSON).Replace(".json", "");
                    string[] repositoryDetail = objRepository.CreateRepositorie(repositoryName, model.Environment.ProjectId);

                    model.Environment.RepositoryIdList[repositoryDetail[1]] = repositoryDetail[0];

                    string jsonSourceCode = model.ReadJsonFile(sourceCodeJSON);

                    //update endpoint ids
                    foreach (string endpoint in model.Environment.ServiceEndpoints.Keys)
                    {
                        string placeHolder = string.Format("${0}$", endpoint);
                        jsonSourceCode = jsonSourceCode.Replace(placeHolder, model.Environment.ServiceEndpoints[endpoint]);
                    }

                    Repository objRepositorySourceCode = new Repository(importSourceConfiguration);
                    bool copySourceCode = objRepositorySourceCode.getSourceCodeFromGitHub(jsonSourceCode, model.ProjectName, repositoryDetail[0]);

                    if (!(string.IsNullOrEmpty(objRepository.lastFailureMessage)))
                    {
                        AddMessage(id.ErrorId(), "Error while importing source code: " + objRepository.lastFailureMessage + Environment.NewLine);
                    }

                }

            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while importing source code: " + ex.Message + ex.StackTrace + Environment.NewLine);

            }
        }

        private void CreateServiceEndPoint(Project model, List<string> jsonPaths, Configuration _defaultConfiguration)
        {
            try
            {
                string serviceEndPointId = string.Empty;
                foreach (string jsonPath in jsonPaths)
                {
                    string jsonCreateService = jsonPath;
                    if (System.IO.File.Exists(jsonCreateService))
                    {
                        ServiceEndPoint objService = new ServiceEndPoint(_defaultConfiguration);
                        jsonCreateService = model.ReadJsonFile(jsonCreateService);
                        jsonCreateService = jsonCreateService.Replace("$ProjectName$", model.ProjectName);
                        var endpoint = objService.CreateServiceEndPoint(jsonCreateService, model.ProjectName);

                        if (!(string.IsNullOrEmpty(objService.lastFailureMessage)))
                        {
                            AddMessage(model.id.ErrorId(), "Error while creating service endpoint: " + objService.lastFailureMessage + Environment.NewLine);
                        }
                        else
                        {
                            model.Environment.ServiceEndpoints[endpoint.name] = endpoint.id;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(model.id.ErrorId(), "Error while creating service endpoint: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        private void CreateBuildDefinition(string templatesFolder, Project model, Configuration _defaultConfiguration, string id)
        {
            try
            {
                foreach (BuildDef buildDef in model.BuildDefinitions)
                {
                    if (System.IO.File.Exists(buildDef.FilePath))
                    {
                        BuildDefinition objBuild = new BuildDefinition(_defaultConfiguration);
                        string jsonBuildDefinition = model.ReadJsonFile(buildDef.FilePath);

                        //update repositoryId 
                        foreach (string repository in model.Environment.RepositoryIdList.Keys)
                        {
                            string placeHolder = string.Format("${0}$", repository);
                            jsonBuildDefinition = jsonBuildDefinition.Replace(placeHolder, model.Environment.RepositoryIdList[repository]);
                        }

                        //update endpoint ids
                        foreach (string endpoint in model.Environment.ServiceEndpoints.Keys)
                        {
                            string placeHolder = string.Format("${0}$", endpoint);
                            jsonBuildDefinition = jsonBuildDefinition.Replace(placeHolder, model.Environment.ServiceEndpoints[endpoint]);
                        }

                        string[] buildResult = objBuild.CreateBuildDefinition(jsonBuildDefinition, model.ProjectName);

                        if (!(string.IsNullOrEmpty(objBuild.lastFailureMessage)))
                        {
                            AddMessage(id.ErrorId(), "Error while creating build definition: " + objBuild.lastFailureMessage + Environment.NewLine);
                        }
                        buildDef.Id = buildResult[0];
                        buildDef.Name = buildResult[1];
                    }
                }
            }

            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while creating build definition: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }
        private void QueueABuild(string templatesFolder, Project model, string json, Configuration _configuration, string id, int buildDefinitionId)
        {
            try
            {
                string jsonQueueABuild = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, json);
                if (System.IO.File.Exists(jsonQueueABuild))
                {
                    jsonQueueABuild = model.ReadJsonFile(jsonQueueABuild);
                    jsonQueueABuild = jsonQueueABuild.Replace("$id", buildDefinitionId.ToString());
                    BuildDefinition objBuild = new BuildDefinition(_configuration);
                    int queueId = objBuild.QueueBuild(jsonQueueABuild, model.ProjectName);

                    if (!string.IsNullOrEmpty(objBuild.lastFailureMessage))
                    {
                        AddMessage(id.ErrorId(), "Error while Queueing build: " + objBuild.lastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while Queueing Build: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        private void CreateReleaseDefinition(string templatesFolder, Project model, Configuration _releaseConfiguration, Configuration _config3_0, string id, TeamMemberResponse.TeamMembers teamMembers)
        {
            try
            {
                var teamMember = teamMembers.value.FirstOrDefault();

                foreach (ReleaseDef relDef in model.ReleaseDefinitions)
                {
                    if (System.IO.File.Exists(relDef.FilePath))
                    {
                        ReleaseDefinition objRelease = new ReleaseDefinition(_releaseConfiguration);
                        string jsonReleaseDefinition = model.ReadJsonFile(relDef.FilePath);
                        jsonReleaseDefinition = jsonReleaseDefinition.Replace("$ProjectName$", model.Environment.ProjectName)
                               .Replace("$ProjectId$", model.Environment.ProjectId)
                               .Replace("$OwnerUniqueName$", teamMember.uniqueName)
                               .Replace("$OwnerId$", teamMember.id)
                            .Replace("$OwnerDisplayName$", teamMember.displayName);

                        foreach (BuildDef ObjBuildDef in model.BuildDefinitions)
                        {
                            //update build ids
                            string placeHolder = string.Format("${0}-id$", ObjBuildDef.Name);
                            jsonReleaseDefinition = jsonReleaseDefinition.Replace(placeHolder, ObjBuildDef.Id);

                            //update agent queue ids
                            foreach (string queue in model.Environment.AgentQueues.Keys)
                            {
                                placeHolder = string.Format("${0}$", queue);
                                jsonReleaseDefinition = jsonReleaseDefinition.Replace(placeHolder, model.Environment.AgentQueues[queue].ToString());
                            }

                            //update endpoint ids
                            foreach (string endpoint in model.Environment.ServiceEndpoints.Keys)
                            {
                                placeHolder = string.Format("${0}$", endpoint);
                                jsonReleaseDefinition = jsonReleaseDefinition.Replace(placeHolder, model.Environment.ServiceEndpoints[endpoint]);
                            }
                        }

                        string[] releaseDef = objRelease.CreateReleaseDefinition(jsonReleaseDefinition, model.ProjectName);
                        relDef.Id = releaseDef[0];
                        relDef.Name = releaseDef[1];

                        if (!(string.IsNullOrEmpty(objRelease.lastFailureMessage)))
                        {
                            AddMessage(id.ErrorId(), "Error while creating release definition: " + objRelease.lastFailureMessage + Environment.NewLine);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while creating release definition: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        public void CreateRelease(string templatesFolder, Project model, string json, Configuration _configuration, string id, int releaseDefinitionId)
        {
            try
            {
                string jsonCreateRelease = string.Format(templatesFolder + @"{0}\{1}", model.SelectedTemplate, json);
                if (System.IO.File.Exists(jsonCreateRelease))
                {
                    jsonCreateRelease = model.ReadJsonFile(jsonCreateRelease);
                    jsonCreateRelease = jsonCreateRelease.Replace("$id", jsonCreateRelease.ToString());
                    ReleaseDefinition objRelease = new ReleaseDefinition(_configuration);
                    objRelease.CreateRelease(jsonCreateRelease, model.ProjectName);

                    if (!string.IsNullOrEmpty(objRelease.lastFailureMessage))
                    {
                        AddMessage(id.ErrorId(), "Error while creating release: " + objRelease.lastFailureMessage + Environment.NewLine);
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(id.ErrorId(), "Error while creating release: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        public void CreateQueryAndWidgets(string templatesFolder, Project model, List<string> lstQueries, Configuration _defaultConfiguration, Configuration _configuration2, Configuration _configuration3, Configuration releaseConfig)
        {
            try
            {
                Querys objWidget = new Querys(_configuration3);
                Querys objQuery = new Querys(_defaultConfiguration);
                List<QueryResponse> queryResults = new List<QueryResponse>();

                //GetDashBoardDetails
                string dashBoardId = objWidget.GetDashBoardId(model.ProjectName);
                int eTag = Convert.ToInt32(objWidget.GetDashboardeTag(dashBoardId, model.ProjectName));

                if (!string.IsNullOrEmpty(objQuery.lastFailureMessage))
                {
                    AddMessage(model.id.ErrorId(), "Error while getting dashboardId: " + objWidget.lastFailureMessage + Environment.NewLine);
                }

                string dashBoardTemplate = string.Format(templatesFolder + @"{0}\Dashboard\Dashboard.json", model.SelectedTemplate);
                if (System.IO.File.Exists(dashBoardTemplate))
                {
                    dynamic dashBoard = new System.Dynamic.ExpandoObject();
                    dashBoard.name = "Working";
                    dashBoard.position = 4;

                    string jsonDashBoard = Newtonsoft.Json.JsonConvert.SerializeObject(dashBoard);
                    string dashBoardIdToDelete = objWidget.CreateNewDashBoard(model.ProjectName, jsonDashBoard);


                    bool isDashboardDeleted = objWidget.DeleteDefaultDashboard(model.ProjectName, dashBoardId);
                    if (isDashboardDeleted)
                    {
                        dashBoardTemplate = model.ReadJsonFile(dashBoardTemplate);

                        string xamarin_DroidBuild = model.BuildDefinitions.Where(x => x.Name == "Xamarin.Droid").FirstOrDefault().Id;
                        string xamarin_IOSBuild = model.BuildDefinitions.Where(x => x.Name == "Xamarin.iOS").FirstOrDefault().Id;
                        string RidesApiBuild = model.BuildDefinitions.Where(x => x.Name == "RidesApi").FirstOrDefault().Id;

                        ReleaseDefinition objrelease = new ReleaseDefinition(releaseConfig);
                        int[] AndroidEnvironmentIds = objrelease.GetEnvironmentIdsByName(model.ProjectName, "Xamarin.Android", "Test in HockeyApp", "Publish to store");
                        string AndroidbuildDefId = model.BuildDefinitions.Where(x => x.Name == "Xamarin.Droid").FirstOrDefault().Id;
                        string AndroidreleaseDefId = model.ReleaseDefinitions.Where(x => x.Name == "Xamarin.Android").FirstOrDefault().Id;

                        int[] IOSEnvironmentIds = objrelease.GetEnvironmentIdsByName(model.ProjectName, "Xamarin.iOS", "Test in HockeyApp", "Publish to store");
                        string IOSbuildDefId = model.BuildDefinitions.Where(x => x.Name == "Xamarin.iOS").FirstOrDefault().Id;
                        string IOSreleaseDefId = model.ReleaseDefinitions.Where(x => x.Name == "Xamarin.iOS").FirstOrDefault().Id;

                        string RidesApireleaseDefId = model.ReleaseDefinitions.Where(x => x.Name == "RidesApi").FirstOrDefault().Id;
                        QueryResponse OpenUserStories = objQuery.GetQueryByPathAndName(model.ProjectName, "Open User Stories", "Shared%20Queries/Current%20Iteration");

                        dashBoardTemplate = dashBoardTemplate.Replace("$RidesAPIReleaseId$", RidesApireleaseDefId).Replace("$RidesAPIBuildId$", RidesApiBuild)
                                                            .Replace("$repositoryId$", model.Environment.RepositoryIdList["bikesharing360"])
                                                            .Replace("$IOSBuildId$", IOSbuildDefId).Replace("$IOSReleaseId$", IOSreleaseDefId).Replace("$IOSEnv1$", IOSEnvironmentIds[0].ToString()).Replace("$IOSEnv2$", IOSEnvironmentIds[1].ToString())
                                                            .Replace("$Xamarin.iOS$", xamarin_IOSBuild)
                                                            .Replace("$Xamarin.Droid$", xamarin_DroidBuild)
                                                            .Replace("$AndroidBuildId$", AndroidbuildDefId).Replace("$AndroidreleaseDefId$", AndroidreleaseDefId).Replace("$AndroidEnv1$", AndroidEnvironmentIds[0].ToString()).Replace("$AndroidEnv2$", AndroidEnvironmentIds[1].ToString())
                                                            .Replace("$OpenUserStoriesId$", OpenUserStories.id)
                                                            .Replace("$projectId$", model.Environment.ProjectId);

                        string isDashBoardCreated = objWidget.CreateNewDashBoard(model.ProjectName, dashBoardTemplate);
                        objWidget.DeleteDefaultDashboard(model.ProjectName, dashBoardIdToDelete);
                    }
                }
                else
                {
                    foreach (string query in lstQueries)
                    {
                        //create query
                        string json = model.ReadJsonFile(query);
                        QueryResponse response = objQuery.CreateQuery(model.ProjectName, json);
                        queryResults.Add(response);

                        if (!string.IsNullOrEmpty(objQuery.lastFailureMessage))
                        {
                            AddMessage(model.id.ErrorId(), "Error while creating query: " + objQuery.lastFailureMessage + Environment.NewLine);
                            return;
                        }

                        string chartName = Path.GetFileName(query);
                        string jsonChart = string.Format(templatesFolder + @"{0}\Dashboard\Charts\{1}", model.SelectedTemplate, chartName);

                        if (System.IO.File.Exists(jsonChart))
                        {
                            //create chart
                            json = model.ReadJsonFile(jsonChart);
                            json = json.Replace("$name$", response.name).Replace("$QueryId$", response.id).Replace("$QueryName$", response.name).Replace("$eTag$", eTag.ToString());
                            bool chartResponse = objWidget.CreateWidget(model.ProjectName, dashBoardId, json);
                            if (chartResponse) { eTag = eTag + 1; }

                        }
                        string widgetName = Path.GetFileName(query);
                        string jsonWidget = string.Format(templatesFolder + @"{0}\Dashboard\Widgets\{1}", model.SelectedTemplate, widgetName);

                        if (System.IO.File.Exists(jsonWidget))
                        {
                            //create widget
                            json = model.ReadJsonFile(jsonWidget);
                            json = json.Replace("$name$", response.name).Replace("$QueryId$", response.id).Replace("$QueryName$", response.name).Replace("$eTag$", eTag.ToString());
                            bool widgetResponse = objWidget.CreateWidget(model.ProjectName, dashBoardId, json);
                            if (widgetResponse) { eTag = eTag + 1; }
                        }
                        if (!string.IsNullOrEmpty(objQuery.lastFailureMessage))
                        {
                            AddMessage(model.id.ErrorId(), "Error while creating widget and charts: " + objWidget.lastFailureMessage + Environment.NewLine);
                        }

                    }
                    //Update WorkInProgress ,UnfinishedWork Queries,Test Cases,Blocked Tasks queries.
                    string UpdateQueryString = string.Empty;

                    UpdateQueryString = "SELECT [System.Id],[System.Title],[Microsoft.VSTS.Common.BacklogPriority],[System.AssignedTo],[System.State],[Microsoft.VSTS.Scheduling.RemainingWork],[Microsoft.VSTS.CMMI.Blocked],[System.WorkItemType] FROM workitemLinks WHERE ([Source].[System.TeamProject] = @project AND [Source].[System.IterationPath] UNDER @currentIteration AND ([Source].[System.WorkItemType] IN GROUP 'Microsoft.RequirementCategory' OR [Source].[System.WorkItemType] IN GROUP 'Microsoft.TaskCategory' ) AND [Source].[System.State] <> 'Removed' AND [Source].[System.State] <> 'Done') AND ([System.Links.LinkType] = 'System.LinkTypes.Hierarchy-Forward')  AND ([Target].[System.WorkItemType] IN GROUP 'Microsoft.TaskCategory' AND [Target].[System.State] <> 'Done' AND [Target].[System.State] <> 'Removed') ORDER BY [Microsoft.VSTS.Common.BacklogPriority],[Microsoft.VSTS.Scheduling.Effort], [Microsoft.VSTS.Scheduling.RemainingWork],[System.Id] MODE (Recursive)";
                    dynamic queryObject = new System.Dynamic.ExpandoObject();
                    queryObject.wiql = UpdateQueryString;
                    bool isUpdated = objQuery.UpdateQuery("Shared%20Queries/Current%20Sprint/Unfinished Work", model.Environment.ProjectName, Newtonsoft.Json.JsonConvert.SerializeObject(queryObject));

                    UpdateQueryString = "SELECT [System.Id],[System.WorkItemType],[System.Title],[System.AssignedTo],[System.State],[Microsoft.VSTS.Scheduling.RemainingWork] FROM workitems WHERE [System.TeamProject] = @project AND [System.IterationPath] UNDER @currentIteration AND [System.WorkItemType] IN GROUP 'Microsoft.TaskCategory' AND [System.State] = 'In Progress' ORDER BY [System.AssignedTo],[Microsoft.VSTS.Common.BacklogPriority],[System.Id]";
                    queryObject.wiql = UpdateQueryString;
                    isUpdated = objQuery.UpdateQuery("Shared%20Queries/Current%20Sprint/Work in Progress", model.Environment.ProjectName, Newtonsoft.Json.JsonConvert.SerializeObject(queryObject));

                    UpdateQueryString = "SELECT [System.Id],[System.WorkItemType],[System.Title],[System.State],[Microsoft.VSTS.Common.Priority] FROM workitems WHERE [System.TeamProject] = @project AND [System.IterationPath] UNDER @currentIteration AND [System.WorkItemType] IN GROUP 'Microsoft.TestCaseCategory' ORDER BY [Microsoft.VSTS.Common.Priority],[System.Id] ";
                    queryObject.wiql = UpdateQueryString;
                    isUpdated = objQuery.UpdateQuery("Shared%20Queries/Current%20Sprint/Test Cases", model.Environment.ProjectName, Newtonsoft.Json.JsonConvert.SerializeObject(queryObject));

                    UpdateQueryString = "SELECT [System.Id],[System.WorkItemType],[System.Title],[Microsoft.VSTS.Common.BacklogPriority],[System.AssignedTo],[System.State],[Microsoft.VSTS.CMMI.Blocked] FROM workitems WHERE [System.TeamProject] = @project AND [System.IterationPath] UNDER @currentIteration AND [System.WorkItemType] IN GROUP 'Microsoft.TaskCategory' AND [Microsoft.VSTS.CMMI.Blocked] = 'Yes' AND [System.State] <> 'Removed' ORDER BY [Microsoft.VSTS.Common.BacklogPriority], [System.Id]";
                    queryObject.wiql = UpdateQueryString;
                    isUpdated = objQuery.UpdateQuery("Shared%20Queries/Current%20Sprint/Blocked Tasks", model.Environment.ProjectName, Newtonsoft.Json.JsonConvert.SerializeObject(queryObject));

                    //Create widgets for default queries[Feedback and  UnfinishedWork]
                    string jsonFeedback = string.Format(templatesFolder + @"{0}\Dashboard\Widgets\Feedback.json", model.SelectedTemplate);
                    if (System.IO.File.Exists(jsonFeedback))
                    {
                        jsonFeedback = model.ReadJsonFile(jsonFeedback);
                        QueryResponse FeedBack = objQuery.GetQueryByPathAndName(model.ProjectName, "Feedback", "Shared%20Queries");
                        jsonFeedback = jsonFeedback.Replace("$QueryId$", FeedBack.id).Replace("$eTag$", eTag.ToString());
                        bool IsFeedback = objWidget.CreateWidget(model.ProjectName, dashBoardId, jsonFeedback);
                        if (IsFeedback) { eTag = eTag + 1; }
                    }
                    string jsonUnfinishedWork = string.Format(templatesFolder + @"{0}\Dashboard\Widgets\Unfinished Work.json", model.SelectedTemplate);
                    if (System.IO.File.Exists(jsonUnfinishedWork))
                    {
                        jsonUnfinishedWork = model.ReadJsonFile(jsonUnfinishedWork);
                        QueryResponse FeedBack = objQuery.GetQueryByPathAndName(model.ProjectName, "Unfinished Work", "Shared%20Queries/Current%20Sprint");
                        jsonUnfinishedWork = jsonUnfinishedWork.Replace("$QueryId$", FeedBack.id).Replace("$eTag$", eTag.ToString());
                        bool IsUnfinishedWork = objWidget.CreateWidget(model.ProjectName, dashBoardId, jsonUnfinishedWork);
                        if (IsUnfinishedWork) { eTag = eTag + 1; }
                    }

                    //Create Custom Charts
                    string jsonUserStoriesByState = string.Format(templatesFolder + @"{0}\Dashboard\Charts\User Stories by State.json", model.SelectedTemplate);
                    if (System.IO.File.Exists(jsonUserStoriesByState))
                    {
                        if (!string.IsNullOrEmpty(queryResults.Where(x => x.name == "User Stories").FirstOrDefault().id))
                        {
                            jsonUserStoriesByState = model.ReadJsonFile(jsonUserStoriesByState);
                            jsonUserStoriesByState = jsonUserStoriesByState.Replace("$QueryId$", queryResults.Where(x => x.name == "User Stories").FirstOrDefault().id).Replace("$eTag$", eTag.ToString());
                            bool isUserStoryByState = objWidget.CreateWidget(model.ProjectName, dashBoardId, jsonUserStoriesByState);
                            if (isUserStoryByState) { eTag = eTag + 1; }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AddMessage(model.id.ErrorId(), "Error while creating Queries and Widgets: " + ex.Message + ex.StackTrace + Environment.NewLine);
            }
        }

        /// <summary>
        /// Modified Code
        /// </summary>
        /// <param name="selectedTemplate"></param>
        /// <returns></returns>
        //[HttpPost]
        //public JsonResult CheckForInstalledExtensions(Details details)//string selectedTemplate)
        //{
        //    try
        //    {
        //        string url = "";// string.Format("http://{0}:{1}/tfs/{2}", details.ServerName, details.Port, details.Collection);
        //        string accountName = string.Empty;
        //        string PAT = string.Empty;

        //        if ( Session["PAT"] != null)
        //        {
        //            PAT = Session["PAT"].ToString();
        //        }
        //        if (Session["AccountName"] != null && Session["PAT"] != null)
        //        {
        //            accountName = Session["AccountName"].ToString();
        //            PAT = Session["PAT"].ToString();
        //        }

        //        //if (details.isTfs)
        //        //{
        //        //    url = string.Format("https://{0}:{1}/tfs/{2}", details.ServerName, details.Port, details.Collection);
        //        //}
        //        //else
        //        {
        //            url = string.Format("https://{0}.visualstudio.com", accountName);
        //        }

        //        string templatesFolder = Server.MapPath("~") + @"\Templates\";
        //        string projTemplateFile = string.Format(templatesFolder + @"{0}\Extensions.json", details.selectedTemplate);
        //        if (!(System.IO.File.Exists(projTemplateFile)))
        //        {
        //            return Json("Template not found", JsonRequestBehavior.AllowGet);
        //        }

        //        string templateItems = System.IO.File.ReadAllText(projTemplateFile);
        //        var template = JsonConvert.DeserializeObject<RequiredExtensions.Extension>(templateItems);
        //        string requiresExtensionNames = string.Empty;

        //        //Check for existing extensions
        //        if (template.Extensions.Length > 0)
        //        {
        //            Dictionary<string, bool> dict = new Dictionary<string, bool>();
        //            foreach (RequiredExtensions.ExtensionWithLink ext in template.Extensions)
        //            {
        //                dict.Add(ext.name, false);
        //            }
        //            var connection = new VssConnection(new Uri(url), new VssBasicCredential(string.Empty, PAT));

        //            var client = connection.GetClient<ExtensionManagementHttpClient>();
        //            var installed = client.GetInstalledExtensionsAsync().Result;
        //            var extensions = installed.Where(x => x.Flags == 0).ToList();

        //            foreach (var ext in extensions)
        //            {
        //                foreach (var extension in template.Extensions)
        //                {
        //                    if (extension.name.ToLower() == ext.ExtensionDisplayName.ToLower())
        //                    {
        //                        dict[extension.name] = true;
        //                    }
        //                }
        //            }
        //            var required = dict.Where(x => x.Value == false).ToList();
        //            if (required.Count > 0)
        //            {
        //                requiresExtensionNames = "Please install following extensions to your VSTS account and try again:<br/><br/><b>";
        //                foreach (var req in required)
        //                {
        //                    string link = template.Extensions.Where(x => x.name == req.Key).FirstOrDefault().link;
        //                    requiresExtensionNames = requiresExtensionNames + link + "<br/><br/>";
        //                }
        //                requiresExtensionNames = requiresExtensionNames + "</b>";
        //                return Json(requiresExtensionNames, JsonRequestBehavior.AllowGet);
        //            }
        //        }
        //        else { requiresExtensionNames = "no extensions required"; return Json(requiresExtensionNames, JsonRequestBehavior.AllowGet); }
        //        return Json(requiresExtensionNames, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json("Error" + ex.Message, JsonRequestBehavior.AllowGet);
        //    }
        //}

        /// <summary>
        /// Unmodified Code
        /// </summary>
        /// <param name="selectedTemplate"></param>
        /// <returns></returns>
        //[HttpGet]
        //public JsonResult CheckForInstalledExtensions(string selectedTemplate)
        //{
        //    try
        //    {
        //        string accountName = string.Empty;
        //        string PAT = string.Empty;

        //        if (Session["AccountName"] != null && Session["PAT"] != null)
        //        {
        //            accountName = Session["AccountName"].ToString();
        //            PAT = Session["PAT"].ToString();
        //        }

        //        string templatesFolder = Server.MapPath("~") + @"\Templates\";
        //        string projTemplateFile = string.Format(templatesFolder + @"{0}\Extensions.json", selectedTemplate);
        //        if (!(System.IO.File.Exists(projTemplateFile)))
        //        {
        //            return Json("Template not found", JsonRequestBehavior.AllowGet);
        //        }

        //        string templateItems = System.IO.File.ReadAllText(projTemplateFile);
        //        var template = JsonConvert.DeserializeObject<RequiredExtensions.Extension>(templateItems);
        //        string requiresExtensionNames = string.Empty;

        //        //Check for existing extensions
        //        if (template.Extensions.Length > 0)
        //        {
        //            Dictionary<string, bool> dict = new Dictionary<string, bool>();
        //            foreach (RequiredExtensions.ExtensionWithLink ext in template.Extensions)
        //            {
        //                dict.Add(ext.name, false);
        //            }
        //            var connection = new VssConnection(new Uri(string.Format("https://{0}.visualstudio.com", accountName)), new VssBasicCredential(string.Empty, PAT));

        //            var client = connection.GetClient<ExtensionManagementHttpClient>();
        //            var installed = client.GetInstalledExtensionsAsync().Result;
        //            var extensions = installed.Where(x => x.Flags == 0).ToList();

        //            foreach (var ext in extensions)
        //            {
        //                foreach (var extension in template.Extensions)
        //                {
        //                    if (extension.name.ToLower() == ext.ExtensionDisplayName.ToLower())
        //                    {
        //                        dict[extension.name] = true;
        //                    }
        //                }
        //            }
        //            var required = dict.Where(x => x.Value == false).ToList();
        //            if (required.Count > 0)
        //            {
        //                requiresExtensionNames = "Please install following extensions to your VSTS account and try again:<br/><br/><b>";
        //                foreach (var req in required)
        //                {
        //                    string link = template.Extensions.Where(x => x.name == req.Key).FirstOrDefault().link;
        //                    requiresExtensionNames = requiresExtensionNames + link + "<br/><br/>";
        //                }
        //                requiresExtensionNames = requiresExtensionNames + "</b>";
        //                return Json(requiresExtensionNames, JsonRequestBehavior.AllowGet);
        //            }
        //        }
        //        else { requiresExtensionNames = "no extensions required"; return Json(requiresExtensionNames, JsonRequestBehavior.AllowGet); }
        //        return Json(requiresExtensionNames, JsonRequestBehavior.AllowGet);
        //    }
        //    catch (Exception ex)
        //    {
        //        return Json("Error" + ex.Message, JsonRequestBehavior.AllowGet);
        //    }
        //}

        /// <summary>
        /// New Code to get available extensions
        /// </summary>
        /// <param name="selectedTemplate"></param>
        /// <returns></returns>
        [HttpPost]
        public JsonResult CheckForInstalledExtensions(string selectedTemplate)
        {
            try
            {
                string templatesPath = Server.MapPath("~") + @"\Templates\";
                if (System.IO.File.Exists(templatesPath + selectedTemplate + "\\Extensions.json"))
                {
                    string templateItems = System.IO.File.ReadAllText(templatesPath + selectedTemplate + "\\Extensions.json");
                    var template = JsonConvert.DeserializeObject<RequiredExtensions.Extension>(templateItems);
                    return Json(template, JsonRequestBehavior.AllowGet);                    
                }
                else
                {
                    return Json("Template not found", JsonRequestBehavior.AllowGet);
                }

            }
            catch(Exception ex)
            {
                return Json("Error" + ex.Message, JsonRequestBehavior.AllowGet);
            }
        }

        #endregion
    }
}





