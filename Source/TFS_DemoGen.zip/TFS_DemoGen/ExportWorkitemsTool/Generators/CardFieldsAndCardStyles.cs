﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using TemplatesGeneratorTool.ViewModel;
using Newtonsoft.Json;

namespace TemplatesGeneratorTool.Generators
{
    public class CardFieldsAndCardStyles
    {
        readonly VstsRestAPI.IConfiguration _sourceConfig;
        readonly string _sourceCredentials;
        readonly string _accountName;

        public CardFieldsAndCardStyles(VstsRestAPI.IConfiguration configuration)
        {
            _sourceConfig = configuration;
            _sourceCredentials = Convert.ToBase64String(System.Text.ASCIIEncoding.ASCII.GetBytes(string.Format("{0}:{1}", "", _sourceConfig.PersonalAccessToken)));
        }

        public void GetCardFields(string project)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_sourceConfig.UriString);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _sourceCredentials);

                HttpResponseMessage response = client.GetAsync(_sourceConfig.UriString + string.Format("{0}/_apis/work/boards/Backlog%20items/cardsettings?api-version=2.0-preview.1", project)).Result;
                if (response.IsSuccessStatusCode)
                {
                    CardFieldResponse.CardFields CardFields = Newtonsoft.Json.JsonConvert.DeserializeObject<CardFieldResponse.CardFields>(response.Content.ReadAsStringAsync().Result.ToString());

                    if (!Directory.Exists("Templates"))
                    {
                        Directory.CreateDirectory("Templates");
                    }

                    string fetchedCardFieldsJSON = JsonConvert.SerializeObject(CardFields, Formatting.Indented);
                    System.IO.File.WriteAllText(@"Templates\UpdateCardFields.json", fetchedCardFieldsJSON);
                }
            }
        }
          
        public void GetCardStyles(string project)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(_sourceConfig.UriString);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Basic", _sourceCredentials);

                HttpResponseMessage response = client.GetAsync(_sourceConfig.UriString + string.Format("{0}/_apis/work/boards/Backlog%20items/cardrulesettings?api-version=2.0-preview.1", project)).Result;
                if (response.IsSuccessStatusCode)
                {
                    CardStyleResponse.CardStyles CardStyles = Newtonsoft.Json.JsonConvert.DeserializeObject<CardStyleResponse.CardStyles>(response.Content.ReadAsStringAsync().Result.ToString());

                    if (!Directory.Exists("Templates"))
                    {
                        Directory.CreateDirectory("Templates");
                    }
                    string fetchedCardStylesJSON = JsonConvert.SerializeObject(CardStyles, Formatting.Indented);
                    System.IO.File.WriteAllText(@"Templates\UpdateCardStyles.json", fetchedCardStylesJSON);
                }
            }
        }
    }
}
        

