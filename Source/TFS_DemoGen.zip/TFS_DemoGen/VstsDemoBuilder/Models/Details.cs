﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VstsDemoBuilder.Models
{
    public class Details
    {
        public string Collection { get; set; }
        public bool isTfs { get; set; }
        public string PAT { get; set; }
        public string ServerName { get; set; }
        public string Port { get; set; }
        public string selectedTemplate { get; set; }
    }
}