﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace VstsDemoBuilder.Models
{
    public class Default
    {
        public const string Agile = "adcc42ab-9882-485e-a3ed-7678f01f66bc";

        public const string SCRUM = "6b724908-ef14-45cf-84f8-768b5384da45";

        public const string CMMI = "27450541-8e31-4150-9947-dc59f998fc01";

        public const string Queue = "Hosted";
    }

    
}